import React from "react";
import Search from "./components/Search";

function App() {
    return (
        <div className="App">
            <h1>Wikipedia Searcher</h1>
            <Search />
        </div>
    );
}

export default App;